一、编译
环境变量说明：
    #指定runtime库源码路径
    RUNTIME ?=
    #指定平台(x86/android/android-64/hi3536/hi3798......)
    PLATFORM ?=

    打开CMakeList.txt文件，根据自己的目标平台情况，选择打开或屏蔽如下宏：
        add_definitions(-DTARGET_MACH=MACH_RK3288_SERIES)
        #add_definitions(-DTARGET_MACH=MACH_LINUX_SERIES)
        #add_definitions(-DTARGET_MACH=MACH_MTK6735_SERIES)

二、使用说明
    2、将编译生成的install文件夹拷贝到开发板上，运行其中的wifi_ap可执行程序
