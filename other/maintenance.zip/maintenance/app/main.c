#include <time.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/sysinfo.h>
#include "st_list.h"

#define WIFI_2G 	0
#define WIFI_2G_5G 	1


#define AP6255 "ap6255"
#define AP6212 "ap6212"
#define AP6210 "ap6210"
#define RTL8821CU "rtl8821cu"

#define VERSION "1.0.0"

static void usage(void)
{
	printf("version:%s\n",VERSION);
	exit(1);
}
int get_best_channel(int type){
    const char *wifi_2g_prefix = "best_channel_24G = ";
    const char *wifi_5g_prefix = "best_channel_5G = ";
    int MAXLINE = 40;
    char buffer[128];
    char vol[20] ={1};
    char vol2[20] ={1};
    int i = 0;
    FILE *fp;

    fp = fopen("/data/best_channels", "r");
    if(fp== NULL) {
        printf("chenhao,打开文件/data/best_channels失败\n");
        return -1;
    }
    printf("chenhao,开始按行读取文件\n");
    for (i=0; i < MAXLINE; i++) {
        if(feof(fp))
            break;
        memset(buffer, 0, sizeof(buffer));
        fgets(buffer, 127, fp);
        printf("chenhao,读取行%s\n",buffer);
        if(strlen(buffer) >= strlen(wifi_5g_prefix)&&!strncmp(buffer, wifi_5g_prefix, strlen(wifi_5g_prefix))) {
            printf("chenhao,读取到best_channel_5G\n");
            strncpy( vol,buffer + strlen(wifi_5g_prefix) , strlen(buffer) - strlen(wifi_5g_prefix)-1);
            // memset(buffer, 0, sizeof(buffer));
            // memset(vol, 0, sizeof(vol));
        }
        if(strlen(buffer) >= strlen(wifi_2g_prefix)&&!strncmp(buffer, wifi_2g_prefix, strlen(wifi_2g_prefix))) {
            printf("chenhao,best_channel_24G\n");
            strncpy( vol2,buffer + strlen(wifi_2g_prefix) , strlen(buffer) - strlen(wifi_2g_prefix)-1);
            // memset(buffer, 0, sizeof(buffer));
            // memset(vol2, 0, sizeof(vol2));
        }

    }
    fclose(fp);
    printf("chenhao,get_best_channel,vol1=%s,vol2=%s\n",vol,vol2);

    if (type == WIFI_2G_5G) {
        printf("chenhao,get_best_channel,当前是5g芯片");
        return atoi(vol);
    } else {
        printf("chenhao,get_best_channel,当前是2.4g芯片");
        return atoi(vol2);
    }
}

int main(int argc, char* argv[])
{
    int ret;
    DIR* dir = NULL;
    int reboot_type_fd;
    char cmd[256] = "";
    char path[256] = "";
    char chip_type[256] = "";
    printf("chenhao,11:25\n");
    int work_mode = WIFI_2G;
    int ap_channel;
    // int chip_type = WIFI_2G_5G;
    int c;
    int temp;
    strcpy(chip_type,"rtl8821cu");//默认芯片
    for (;;) {
		c = getopt(argc, argv, "m:c:t:");
		if (c < 0)
			break;
		switch (c) {
            case 't':
                if(strcmp(optarg,"ap6255")==0)
                    strcpy(chip_type,"ap6255");
                else if(strcmp(optarg,"ap6212")==0)
                    strcpy(chip_type,"ap6212");
                else if(strcmp(optarg,"ap6210")==0)
                    strcpy(chip_type,"ap6210");
                else if(strcmp(optarg,"rtl8821cu")==0)
                    strcpy(chip_type,"rtl8821cu");
                else {
                    strcpy(chip_type,"rtl8821cu");
                    printf("芯片类型无法识别\n");
                }
                
			    break;
        	case 'm':
                if(strcmp(optarg,"5g")==0)
                    work_mode = WIFI_2G_5G;//1
                else if(strcmp(optarg,"2.4g")==0)
                    work_mode = WIFI_2G;//0
                else
                {
                    work_mode = WIFI_2G;
                    printf("工作模式不支持");
                }
                
			    break;
            case 'c':
                temp = atoi(optarg);
                
                if(temp<-1||temp>165){
                     printf("无效的工作模式\n");
                     if(work_mode==WIFI_2G_5G)
                        ap_channel = 6;
                     else 
                        ap_channel = 161;
                } else {
                    ap_channel = temp;
                }
               
			    break;
            case 'h':
                usage();
                break;
            default:
                usage();
                break;
		}
	}
    printf("chenhao，参数处理完毕，当前的channel=%d,work_mode=%d\n",ap_channel,work_mode);
    
    if(ap_channel==-1){
        /**************stage 1 判断当前环境****************/
        if (access("/etc/hostapd.conf", F_OK) != 0) {
            printf("热点配置文件不存在，直接返回\n");
            return -1;
        }
        if (access("/usr/bin/iwlist2", F_OK) != 0) {
            printf("信道自动选择程序不存在，直接返回\n");
            return -1;
        }

        /**************stage 2 执行iwlist，等待执行结束****************/
        sprintf(cmd, "iwlist2 -p %s wlan0 scan > /dev/null", chip_type);
        // if(1){
        //     printf("命令是%s\n",cmd);
        // printf("chenhao:17:40\n");
        // return 0;
        // }

        printf("打开wlan0\n");
        system("busybox ifconfig wlan0 up");
        printf("执行iwlist2\n");
        system(cmd);
        printf("关闭wlan0\n");
        system("busybox ifconfig wlan0 down");
        
        /**************stage 3 读取结果****************/

        ap_channel = get_best_channel(work_mode);
        printf("chenhao,the best_channel is %d\n",ap_channel);

        }
    /**************stage 4 判断结果合法性，新增配置文件hostapd.conf_bak****************/
     system("cp /etc/hostapd.conf /etc/hostapd.conf_bak");
     memset(cmd, 0, sizeof(cmd));
    sprintf(cmd, "sed -i '/^channel=6/cchannel=%d' /etc/hostapd.conf_bak", ap_channel);
    printf("替换命令是%s\n",cmd);
    system(cmd);

    if(work_mode==WIFI_2G_5G){
        memset(cmd, 0, sizeof(cmd));
        sprintf(cmd, "sed -i '/^hw_mode=g/chw_mode=a' /etc/hostapd.conf_bak");
        system(cmd);
    }
    

    /**************stage 4 开启热点****************/
    system("hostapd /etc/hostapd.conf_bak&");
    printf("chenhao:17:55\n");
    return 0;
}
